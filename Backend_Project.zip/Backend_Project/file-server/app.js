const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 8080;

// Middleware to log every request
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url} - ${req.headers['user-agent']}`);
  next();
});

// Endpoint to create a file
app.post('/createFile', (req, res) => {
  const { filename, content, password } = req.body;

  if (!filename ||!content) {
    return res.status(400).send('Missing required parameters: filename, content');
  }

  const filePath = path.join(__dirname, filename);
  const fileExtension = path.extname(filename).slice(1);

  if (!['log', 'txt', 'json', 'yaml', 'xml', 'js'].includes(fileExtension)) {
    return res.status(400).send('Unsupported file extension');
  }

  fs.writeFile(filePath, content, (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error writing file');
    }
    res.send('File created successfully');
  });
});

// Endpoint to get a list of uploaded files
app.get('/getFiles', (req, res) => {
  fs.readdir(__dirname, (err, files) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error reading directory');
    }
    res.send(files.filter((file) => file!== 'app.js'));
  });
});

// Endpoint to get file content
app.get('/', (req, res) => {
  const { filename } = req.params;
  const { password } = req.query;

  if (!filename) {
    return res.status(400).send('Missing required parameter: filename');
  }

  const filePath = path.join(__dirname, filename);
  const fileExtension = path.extname(filename).slice(1);

  if (!['log', 'txt', 'json', 'yaml', 'xml', 'js'].includes(fileExtension)) {
    return res.status(400).send('Unsupported file extension');
  }

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.status(404).send('File not found');
      }
      console.error(err);
      return res.status(500).send('Error reading file');
    }

    if (password && data.includes(`password: ${password}`)) {
      return res.send(data);
    } else if (!password) {
      return res.send(data);
    } else {
      return res.status(401).send('Invalid or missing password');
    }
  });
});

// Optional endpoint to modify file content
app.put('/modifyFile/:filename', (req, res) => {
  const { filename } = req.params;
  const { content, password } = req.body;

  if (!filename ||!content) {
    return res.status(400).send('Missing required parameters: filename, content');
  }

  const filePath = path.join(__dirname, filename);
  const fileExtension = path.extname(filename).slice(1);

  if (!['log', 'txt', 'json', 'yaml', 'xml', 'js'].includes(fileExtension)) {
    return res.status(400).send('Unsupported file extension');
  }

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.status(404).send('File not found');
      }
      console.error(err);
      return res.status(500).send('Error reading file');
    }

    if (password && data.includes(`password: ${password}`)) {
      fs.writeFile(filePath, content, (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Error writing file');
        }
        res.send('File modified successfully');
      });
    } else if (!password) {
      fs.writeFile(filePath, content, (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Error writing file');
        }
        res.send('File modified successfully');
      });
    } else {
      return res.status(401).send('Invalid or missing password');
    }
  });
});

// Optional endpoint to delete a file
app.delete('/deleteFile/:filename', (req, res) => {
  const { filename } = req.params;
  const { password } = req.query;

  if (!filename) {
    return res.status(400).send('Missing required parameter: filename');
  }

  const filePath = path.join(__dirname, filename);

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.status(404).send('File not found');
      }
      console.error(err);
      return res.status(500).send('Error reading file');
    }

    if (password && data.includes(`password: ${password}`)) {
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Error deleting file');
        }
        res.send('File deleted successfully');
      });
    } else if (!password) {
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Error deleting file');
        }
        res.send('File deleted successfully');
      });
    } else {
      return res.status(401).send('Invalid or missing password');
    }
  });
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});